// Define a custom dynamic array template class
template <typename T>
class Vector {
private:
    T* arr;           // Pointer to the dynamic array
    int capacity;     // Total capacity of the dynamic array
    int current;      // Current number of elements

public:
    // Constructor: Initialize an empty dynamic array
    Vector() : arr(new T[1]), capacity(1), current(0) {}

    // Destructor: Deallocate memory for the dynamic array
    ~Vector() {
        delete[] arr;
    }

    // Function to add an element at the end of the dynamic array
    void push_back(T data) {
        // Check if the dynamic array is full, if so, double its capacity
        if (current == capacity) {
            capacity *= 2;
            T* temp = new T[capacity];

            // Copy elements from the old array to the new array
            for (int i = 0; i < current; i++) {
                temp[i] = arr[i];
            }

            // Deallocate memory for the old array and update the pointer
            delete[] arr;
            arr = temp;
        }

        // Add the new element and increment the current count
        arr[current] = data;
        current++;
    }

    // Function to get an element at a specific index
    T get(int index) const {
        if (index < current) {
            return arr[index];
        }
        else {
            throw std::out_of_range("Index out of range");
        }
    }

    // Function to remove the last element from the dynamic array
    void pop() {
        if (current > 0) {
            current--;
        }
    }

    // Function to get the current size (number of elements) of the dynamic array
    int size() const {
        return current;
    }

    // Function to get the capacity of the dynamic array
    int getCapacity() const {
        return capacity;
    }

    // Function to get an iterator to the beginning of the dynamic array
    T* begin() {
        return arr;
    }

    // Function to resize the dynamic array to a new size
    void resize(int newSize) {
        if (newSize > capacity) {
            // Increase capacity and allocate new memory if needed
            while (capacity < newSize) {
                capacity *= 2;
            }

            T* temp = new T[capacity];
            for (int i = 0; i < current; ++i) {
                temp[i] = arr[i];
            }
            delete[] arr;
            arr = temp;
        }

        // If the new size is smaller, reduce the current size
        if (newSize < current) {
            current = newSize;
        }

        // Initialize any new elements added
        for (int i = current; i < newSize; ++i) {
            arr[i] = T();  // Initialize with the default value of T
        }

        // Update the current size to the new size
        current = newSize;
    }

    // Function to get an iterator to the end of the dynamic array
    T* end() {
        return arr + current;
    }

    // Overload the [] operator to access elements in the dynamic array
    T& operator[](int index) {
        if (index < current) {
            return arr[index];
        }
        else {
            throw std::out_of_range("Index out of range");
        }
    }
};
