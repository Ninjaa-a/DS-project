﻿// Hammad 22i-2433
// Abdullah Asif 22i-1527
// SE-D

#include<iostream> // for input outpur
#include<random> // for random distribution
#include<string> // for string
#include<conio.h> // for sleep and clear
#include<iomanip> // for setw
#include<chrono> // for time
#include<thread> // for time
#include<fstream> // for file reading and writing
#include<ctime> // for rime
#include"vector.h" // for own vector library
#include<windows.h> // for sleep and cls
#include<cstdlib> // for cls
#include"CustomStack.h" // for stack library
#include"Powerup.h" // for powerup list
#include"LeaderBoard.h" // for own leaderboard list
#include"CustomQueue.h" // for queue library
#include"CustomPriorityQueue.h" // for custom Queue

#define RED     "\033[31m"
#define GREEN   "\033[32m"
#define YELLOW  "\033[93m"
#define BLUE    "\033[34m"
#define MAGENTA "\033[35m"
#define CYAN    "\033[36m"
#define DARKGREEN    "\033[92m"
#define DEFAULT "\033[37m"
using namespace std;

Node* leaderboardRoot = nullptr; // Global root for the BST
// Constants for time-based scoring
const int TIME_BONUS_THRESHOLD = 60; // Time (in seconds) to beat for a bonus
const int TIME_BONUS_PER_SECOND = 10; // Bonus points per second under threshold
const int TIME_PENALTY_THRESHOLD = 120; // Time (in seconds) after which penalty starts
const int TIME_PENALTY_PER_SECOND = -5; // Penalty points per second over threshold


struct ScoreEntry {
	std::string username;
	int score;

	ScoreEntry(const std::string& name, int s) : username(name), score(s) {}
};

bool compareScores(const ScoreEntry& a, const ScoreEntry& b) {
	return a.score > b.score;
}

void readLeaderboard() {
	std::ifstream leaderboardFile("leaderboard.txt");
	std::string username;
	int score, gameDuration;

	if (leaderboardFile.is_open()) {
		while (leaderboardFile >> username >> score >> gameDuration) {
			leaderboardRoot = insert_the_players_details(leaderboardRoot, username, score, gameDuration);
		}
		leaderboardFile.close();
	}
	else {
		std::cerr << RED <<  "Error: Unable to open leaderboard file for reading." << RESET << std::endl;
	}
}




struct Edge {
	int dest;
	//int weight;
	Edge* next;

	Edge(int dest, Edge* next = NULL) {
		this->dest = dest;
		this->next = next;
	}

};


class Vertex {
public:
	int value;
	int vertexId;
	Edge* EdgeListHead, * EdgeListTail;
	//list<Edge*> EdgeList;
	Vertex() : value(0) { EdgeListHead = NULL; EdgeListTail = NULL; }
	Vertex(int val, int id = 0) : value(val), vertexId(id) {  }
	void addEdge(Edge* obj)
	{
		Edge* newNode = obj;
		if (EdgeListHead == NULL) {
			EdgeListHead = EdgeListTail = newNode;
		}
		else {
			EdgeListTail->next = newNode;
			EdgeListTail = newNode;
		}
	}
	void DisplayList()
	{
		Edge* Current = EdgeListHead;
		while (Current)
		{
			cout << Current->dest << " ";
			Current = Current->next;
		}
	}
};

// Obstacle c
class Obstacle {
public:
	int x, y; // Position of the obstacle
	char type; // Type of the obstacle

	Obstacle(int x, int y, char type) : x(x), y(y), type(type) {}
};

class Graph {
	int rows, columns;
	Vertex** Map;
	Vertex** UserMap;


	vector<vector<int>> adjList;

	CustomQueue<std::pair<int, int>> obstacleQueue;
	int highestScore = 0; // Variable to store the highest score
	PowerUpList collectedPowerUps;
	int score = 10;
	int gameDuration = 0;
	int carX = 1, carY = 1;
	bool hasReachedEnd = false;

public:
	//int gameDuration;
	Graph(int r, int c) : rows(r), columns(c), score(0), gameDuration(0), carX(1), carY(1), hasReachedEnd(false) {
		Map = new Vertex * [rows];
		for (int i = 0; i < rows; i++) {
			Map[i] = new Vertex[columns];
		}
		UserMap = new Vertex * [rows];
		for (int i = 0; i < rows; i++) {
			UserMap[i] = new Vertex[columns];
		}
		adjList.resize(rows * columns);
	}
	int getRows() const { return rows; }
	int getColumns() const { return columns; }
	int getScore() const {
		return score;
	}
	int getDuration() {
		return gameDuration;
	}
	void setDuration(int duration) {
		this->gameDuration = duration;
	}

	void addWeightedEdge(int src, int dest) {
		// Ensure src and dest are within the grid
		if (src < 0 || src >= rows * columns || dest < 0 || dest >= rows * columns) {
			cout << RED << "Invalid source or destination" << RESET << endl;
			return;
		}

		int srcRow = src / columns;
		int srcCol = src % columns;
		int destRow = dest / columns;
		int destCol = dest % columns;

		// Create new edge from src to dest

		Edge* newEdgeSrcToDest = new Edge(Map[destRow][destCol].vertexId);
		Map[srcRow][srcCol].addEdge(newEdgeSrcToDest);
		adjList[Map[srcRow][srcCol].vertexId].push_back(Map[destRow][destCol].vertexId);

	}
	void createMap()
	{
		Vertex Wall(-1);
		Vertex Path(1);
		Vertex Car(0);
		Vertex Power(2);
		Vertex Finish(100);
		int r = 0;
		for (int i = 0; i < rows; i++)
		{
			for (int j = 0; j < columns; j++)
			{

				Map[i][j] = Path;
				Map[i][j].vertexId = r;
				r++;

			}
		}
		for (int i = 0; i < rows; ++i) {

			Map[i][0] = Wall;
			Map[i][columns - 1].value = -1;

		}
		for (int j = 0; j < columns; ++j) {
			Map[0][j] = Wall;
			Map[rows - 1][j].value = -1;

		}

		std::default_random_engine generator(std::chrono::system_clock::now().time_since_epoch().count());
		uniform_int_distribution<int> distribution(1, rows - 2); // Adjust range inside the boundary
		for (int i = 0; i < (rows * columns) / 5; i++)
		{
			int r = distribution(generator);
			int c = distribution(generator);
			Map[r][c].value = -1;
		}
		for (int i = 0; i < rows / 2; i++)
		{
			int r = distribution(generator);
			int c = distribution(generator);
			Map[r][c].value = 2;
		}

		for (int i = 0; i < rows; i++)
		{
			for (int j = 0; j < columns; j++)
			{

				UserMap[i][j] = Map[i][j];

			}
		}
		generateObstacles();
		for (int i = 1; i < rows - 1; ++i) {
			for (int j = 1; j < columns - 1; ++j) {
				int current = i * columns + j; // Current vertex index

					// Connect with the vertex above (up)
				if (Map[i - 1][j].value != -1 && Map[i][j].value != -1) {
					addWeightedEdge(current, (i - 1) * columns + j);
				}

				// Connect with the vertex below (down)
				if (Map[i + 1][j].value != -1 && Map[i][j].value != -1) {
					addWeightedEdge(current, (i + 1) * columns + j);
				}

				// Connect with the vertex to the left (left)
				if (Map[i][j - 1].value != -1 && Map[i][j].value != -1) {
					addWeightedEdge(current, i * columns + (j - 1));
				}

				// Connect with the vertex to the right (right)
				if (Map[i][j + 1].value != -1 && Map[i][j].value != -1) {
					addWeightedEdge(current, i * columns + (j + 1));
				}

			}
		}

		Map[1][1] = Car;
		Map[rows - 2][columns - 2] = Finish;


	}

	// Define a stack to store the path for the car to follow
	CustomStack<pair<int, int>> carPath;

	// Implement Dijkstra's algorithm to find the shortest path
	void dijkstra(int startX, int startY, int endX, int endY) {
		vector<vector<pair<int, int>>> parent(rows, vector<pair<int, int>>(columns, { -1, -1 }));
		vector<vector<int>> distance(rows, vector<int>(columns, INT_MAX));
		CustomPriorityQueue<pair<int, pair<int, int>>, greater<pair<int, pair<int, int>>>> pq;

		// Initialize the source vertex
		distance[startX][startY] = 0;
		pq.push({ 0, {startX, startY} });

		// Define direction arrays for moving in 4 directions
		int dr[] = { -1, 1, 0, 0 };
		int dc[] = { 0, 0, -1, 1 };

		while (!pq.isEmpty()) {
			int dist = pq.top().first;
			int r = pq.top().second.first;
			int c = pq.top().second.second;
			pq.pop();

			if (dist > distance[r][c]) continue;

			for (int i = 0; i < 4; ++i) {
				int newR = r + dr[i];
				int newC = c + dc[i];

				if (isValidMove(newR, newC) && distance[newR][newC] > distance[r][c] + 1) {
					distance[newR][newC] = distance[r][c] + 1;
					parent[newR][newC] = { r, c };
					pq.push({ distance[newR][newC], {newR, newC} });
				}
			}
		}

		// Store the path in the carPath stack by backtracking from the destination to the source
		int curX = endX;
		int curY = endY;

		while (curX != startX || curY != startY) {
			carPath.push({ curX, curY });
			pair<int, int> next = parent[curX][curY];
			curX = next.first;
			curY = next.second;
		}
	}
	void displayMap()
	{

		for (int i = 0; i < rows; i++)
		{
			for (int j = 0; j < columns; j++)
			{
				if (i == 0 || i == rows - 1)
				{
					char w = 254;
					cout << CYAN << w << " " << DEFAULT;
				}
				else {
					if (Map[i][j].value == 0) {
						cout << MAGENTA << "\033[0m" << "\033[5mC" << " " << "\033[0m" << RESET;
					}
					else if (Map[i][j].value == -5)
					{
						char p = 'O';
						cout << RED << p << " " << DEFAULT;
					}
					else if (Map[i][j].value == -1)
					{
						char w = 254;
						cout << CYAN << w << " " << DEFAULT;
					}
					else if (Map[i][j].value == 1)
					{
						cout << ". ";
					}
					else if (Map[i][j].value == 2)
					{
						char p = '*';
						cout << MAGENTA << p << " " << DEFAULT;
					}
					else if (Map[i][j].value == 100)
					{

						cout << CYAN << "\033[1m" << "\033[5mE" << " " << DEFAULT << "\033[0m";
					}
				}


			}
			cout << endl;
		}
		cout << GREEN << "\033[1m" << "\033[5mScore : " << score << DEFAULT  << "\033[0m" << endl;
	}
	bool isValidMove(int x, int y) {
		if (Map[x][y].value != -1) {

			return true;
		}
		return false;
	}
	void generateObstacles() {
		default_random_engine generator(std::chrono::system_clock::now().time_since_epoch().count());

		//std::default_random_engine generator;
		std::uniform_int_distribution<int> distribution(1, rows - 2);

		for (int i = 0; i < (rows * columns) / 15; i++) {
			int r = distribution(generator);
			int c = distribution(generator);

			if (Map[r][c].value != -1 && Map[r][c].value != 0 && Map[r][c].value != 100 && Map[r][c].value != 2) { // Check if the position is not already an obstacle
				Map[r][c].value = -5; // Set as an obstacle
				obstacleQueue.enqueue(std::make_pair(r, c)); // Store the position in the queue
			}
		}
	}


	void moveCar() {
		// Time calculation
		auto start = std::chrono::steady_clock::now();
		bool isPaused = false; // Flag to check if the game is paused

		while (!hasReachedEnd) {
			char direction;

			// Check if the game is paused
			if (!isPaused) {
				direction = _getch();
			}
			else {
				// If the game is paused, wait for Esc to resume
				while (true) {
					char resumeKey = _getch();
					if (resumeKey == 27) { // 27 is the ASCII code for Esc
						isPaused = false;
						break;
					}
				}
				continue; // Skip the rest of the loop when paused
			}

			auto now = std::chrono::steady_clock::now();
			auto elapsed = std::chrono::duration_cast<std::chrono::seconds>(now - start).count();

			std::cout << RED <<  "\rElapsed time: " << elapsed << " seconds" << RESET;
			std::this_thread::sleep_for(std::chrono::milliseconds(100));

			switch (direction) {
			case 'W':
			case 'w':
				if (!isPaused && isValidMove(carX - 1, carY)) {
					UserMap[carX][carY].value = 10; // Store user's path
					Map[carX][carY].value = 1;
					--carX;
					if (Map[carX][carY].value == -5) {
						score -= 2;

						if (score <= 0) {
							hasReachedEnd = true;
						}
					}
					else if (Map[carX][carY].value == 2) { // Assuming 2 represents a power-up
						// Collect the power-up
						collectedPowerUps.addPowerUp(PowerUp(carX, carY, '*')); // 'P' for PowerUp
						// Remove the power-up from the map
						Map[carX][carY].value = 1; // Assuming 1 represents an empty space
						score += 5;
					}
					else if (Map[carX][carY].value == 100)
					{
						hasReachedEnd = true;
					}
					Map[carX][carY].value = 0;
					system("CLS");
					displayMap();
				}
				break;
			case 'A':
			case 'a':
				if (!isPaused && isValidMove(carX, carY - 1)) {
					UserMap[carX][carY].value = 20; // Store user's path
					Map[carX][carY].value = 1;
					--carY;
					if (Map[carX][carY].value == -5) {
						score -= 2;
						if (score <= 0) {
							hasReachedEnd = true;
						}
					}
					else if (Map[carX][carY].value == 2) { // Assuming 2 represents a power-up
						// Collect the power-up
						collectedPowerUps.addPowerUp(PowerUp(carX, carY, '*')); // 'P' for PowerUp
						// Remove the power-up from the map
						Map[carX][carY].value = 1; // Assuming 1 represents an empty space
						score += 5;
					}
					else if (Map[carX][carY].value == 100)
					{
						hasReachedEnd = true;
					}
					Map[carX][carY].value = 0;
					system("CLS");
					displayMap();
				}
				break;
			case 'S':
			case 's':
				if (!isPaused && isValidMove(carX + 1, carY)) {
					UserMap[carX][carY].value = 30; // Store user's path
					Map[carX][carY].value = 1;
					++carX;
					if (Map[carX][carY].value == -5) {
						score -= 2;
						if (score <= 0) {
							hasReachedEnd = true;
						}
					}
					else if (Map[carX][carY].value == 2) { // Assuming 2 represents a power-up
						// Collect the power-up
						collectedPowerUps.addPowerUp(PowerUp(carX, carY, '*')); // 'P' for PowerUp
						// Remove the power-up from the map
						Map[carX][carY].value = 1; // Assuming 1 represents an empty space
						score += 5;
					}
					else if (Map[carX][carY].value == 100)
					{
						hasReachedEnd = true;
					}
					Map[carX][carY].value = 0;
					system("CLS");
					displayMap();
				}
				break;
			case 'D':
			case 'd':
				if (!isPaused && isValidMove(carX, carY + 1)) {
					UserMap[carX][carY].value = 40; // Store user's path
					Map[carX][carY].value = 1;
					++carY;

					if (Map[carX][carY].value == -5) {
						score -= 2;
						if (score <= 0) {
							hasReachedEnd = true;
							return;
						}
					}
					else if (Map[carX][carY].value == 2) { // Assuming 2 represents a power-up
						// Collect the power-up
						collectedPowerUps.addPowerUp(PowerUp(carX, carY, '*')); // 'P' for PowerUp
						// Remove the power-up from the map
						Map[carX][carY].value = 1; // Assuming 1 represents an empty space
						score += 5;
					}
					else if (Map[carX][carY].value == 100)
					{
						hasReachedEnd = true;
					}
					Map[carX][carY].value = 0;
					system("CLS");
					displayMap();
				}
				break;
			case 32:
				// Spacebar: Toggle pause/resume
				isPaused = !isPaused;
				if (isPaused) {
					resume();
				}
				isPaused = !isPaused;
				break;
			default:
				break;
			}


		}
		auto end = std::chrono::steady_clock::now();
		gameDuration = std::chrono::duration_cast<std::chrono::seconds>(end - start).count();

		// Apply time-based scoring
		if (gameDuration < TIME_BONUS_THRESHOLD) {
			score += (TIME_BONUS_THRESHOLD - gameDuration) * TIME_BONUS_PER_SECOND;
		}
		else if (gameDuration > TIME_PENALTY_THRESHOLD) {
			score += (TIME_PENALTY_THRESHOLD - gameDuration) * TIME_PENALTY_PER_SECOND;
		}
	}

	void resume()
	{
		char r = ' ';

		system("CLS");
		gotoxy(40, 5); std::cout << CYAN << "Pause!";
		gotoxy(40, 7); std::cout << "Press ESC key to resume" << std::endl;

		while (true) {
			char resumeKey = _getch();
			if (resumeKey == 27) { // 27 is the ASCII code for Esc
				break;
			}
		}
		cout << RED << RESET;
		system("CLS");
		displayMap();
	}



	void calculateShortestPath() {
		int startX = 1;
		int startY = 1;
		int endX = rows - 2;
		int endY = columns - 2;

		dijkstra(startX, startY, endX, endY);
	}

	void displayMapWithPath() {
		for (int i = 0; i < rows; i++) {
			for (int j = 0; j < columns; j++) {
				if (i == 0 || i == rows - 1) {
					char w = 254;
					cout << w << " ";
				}
				else {
					if (UserMap[i][j].value == 10) {
						cout << GREEN << "|" << DEFAULT << " "; // Print user's path
					}
					else if (UserMap[i][j].value == 20) {
						cout << GREEN << "<" << DEFAULT << " "; // Print user's path
					}
					else if (UserMap[i][j].value == 30) {
						cout << GREEN << "|" << DEFAULT << " "; // Print user's path
					}
					else if (UserMap[i][j].value == 40) {
						cout << GREEN << ">" << DEFAULT << " "; // Print user's path
					}
					else if (Map[i][j].value == -5) {
						cout << RED << "O" << DEFAULT << " "; // Print obstacle
					}
					else if (Map[i][j].value == -1) {
						char w = 254;
						cout << w << " "; // Print wall
					}
					else if (Map[i][j].value == 1) {
						cout << ". "; // Print path
					}
					else if (Map[i][j].value == 2) {
						char p = '*';
						cout << p << " "; // Print power-up
					}
					else if (Map[i][j].value == 100) {
						cout << GREEN << "\033[1m" << " \033[5E" << " " << "\033[0m"; // Print destination
					}
					else {
						cout << "  ";
					}
				}
			}
			cout << endl;
		}
		cout << GREEN << "\033[1m" << " \033[5mScore : " << score << endl << "\033[0m";
		cout << GREEN << "\033[1m" << " \033[5mElapsed Time: " << gameDuration << " seconds" << "\033[0m" << endl;
	}


	void displayGraph() {
		cout << "Graph Representation:" << endl;
		for (int i = 0; i < rows; ++i) {
			for (int j = 0; j < columns; ++j) {
				// Display the vertex
				cout << "Vertex [" << i << "][" << j << "] -> ";

				Map[i][j].DisplayList();

				cout << endl;
			}
		}
	}
	void displayAdjList() {
		for (int i = 0; i < adjList.size(); i++) {
			cout << "Node " << i << ":";
			for (int j : adjList[i]) {
				cout << " " << j;
			}
			cout << endl;
		}
	}

	void startGame() {
		system("CLS");
		gotoxy(43, 9); cout << DEFAULT << "Select Mode";
		gotoxy(41, 10); cout << YELLOW << " +----------------------+ ";
		gotoxy(41, 11); cout << YELLOW << " | " << BLUE << "(1) Manual           " << YELLOW << "| ";
		gotoxy(41, 12); cout << YELLOW << " +----------------------+ ";
		gotoxy(41, 13); cout << YELLOW << " | " << BLUE << "(2) Automatic        " << YELLOW << "| ";
		gotoxy(41, 14); cout << YELLOW << " +----------------------+ ";
		char a;
		a = _getch();
		switch (a)
		{
		case '1':
		{
			Play();
		}
		break;
		case '2':
		{
			Auto();
		}
		break;
		}
		// Additional code to wait before closing the console window
		cout << "Press any key to continue...";
		_getch();
	}
	void Play()
	{
		// Reset the game state for a new game
		score = 0;
		hasReachedEnd = false;
		carX = 1;
		carY = 1;

		// Recreate the map
		//createValidMap(*this); // Corrected call
		Map[carX][carY].value = 0; // Reset the car's position on the map
		Map[rows - 2][columns - 2] = 100; // Reset the end position on the map
		system("CLS");
		displayMap();
		moveCar();
		calculateShortestPath(); // Calculate shortest path after the game is over
		system("CLS");
		cout << RED << "\033[5mGame Over!" << endl << "\033[0m" << RESET << endl;
		displayCollectedPowerUps();
		cout << MAGENTA << "\033[0mUser's Path:" << "\033[0m" << RESET << endl;
		displayMapWithPath(); // Display user's path

		// Display the shortest path
		cout << endl << CYAN << "Shortest Path:" << DEFAULT << endl;
		displayShortestPath();
	}

	void Auto()
	{
		calculateShortestPath();
		system("CLS");
		displayMap();
		MoveAuto();
	}
	void displayShortestPath() {
		// Copy the user map to a temporary map
		Vertex** tempMap = new Vertex * [rows];
		for (int i = 0; i < rows; i++) {
			tempMap[i] = new Vertex[columns];
			for (int j = 0; j < columns; j++) {
				tempMap[i][j] = UserMap[i][j];
			}
		}

		// Mark the shortest path on the temporary map
		while (!carPath.isEmpty()) {
			pair<int, int> pos = carPath.top();
			carPath.pop();
			tempMap[pos.first][pos.second].value = -2; // Mark shortest path
		}

		// Display the updated grid with the shortest path
		for (int i = 0; i < rows; i++) {
			for (int j = 0; j < columns; j++) {
				if (i == 0 || i == rows - 1) {
					char w = 254;
					cout << w << " ";
				}
				else {
					if (tempMap[i][j].value == 10 || tempMap[i][j].value == 20 || tempMap[i][j].value == 30 || tempMap[i][j].value == 40) {
						cout << GREEN << "." << DEFAULT << " "; // Print user's path
					}
					else if (tempMap[i][j].value == -5) {
						cout << RED << "O" << DEFAULT << " "; // Print obstacle
					}
					else if (tempMap[i][j].value == -1) {
						char w = 254;
						cout << w << " "; // Print wall
					}
					else if (tempMap[i][j].value == 1) {
						cout << ". "; // Print path
					}
					else if (tempMap[i][j].value == 2) {
						char p = '*';
						cout << p << " "; // Print power-up
					}
					else if (tempMap[i][j].value == 100) {
						cout << "E" << " "; // Print destination
					}
					else if (tempMap[i][j].value == -2) {
						cout << DARKGREEN << "\033[5mX" << DEFAULT << " \033[0m"; // Print shortest path
					}
					else {
						cout << "  ";
					}
				}
			}
			cout << endl;
		}


	}

	void MoveAuto() {
		// Copy the user map to a temporary map
		Vertex** tempMap = new Vertex * [rows];

		bool reached = false;
		for (int i = 0; i < rows; i++) {
			tempMap[i] = new Vertex[columns];
			for (int j = 0; j < columns; j++) {
				tempMap[i][j] = Map[i][j];
			}
		}
		while (!carPath.isEmpty()) {
			pair<int, int> pos = carPath.top();
			carPath.pop();
			tempMap[pos.first][pos.second].value = -2; // Mark shortest path
		}
		int r = 1, c = 1;

		while (r != rows - 2 || c != columns - 2)
		{
			Sleep(1000);
			if (tempMap[r - 1][c].value == -2)
			{
				tempMap[r][c].value = 10;
				r--;


				tempMap[r][c].value = 0;
				system("CLS");

			}
			else if (tempMap[r][c - 1].value == -2)
			{
				tempMap[r][c].value = 20;
				c--;


				tempMap[r][c].value = 0;
				system("CLS");

			}
			else if (tempMap[r + 1][c].value == -2)
			{
				tempMap[r][c].value = 30;
				r++;

				if (tempMap[r][c].value == 100)
				{
					reached = true;
				}
				tempMap[r][c].value = 0;
				system("CLS");

			}
			else if (tempMap[r][c + 1].value == -2)
			{
				tempMap[r][c].value = 40;
				c++;


				tempMap[r][c].value = 0;
				system("CLS");

			}
			for (int i = 0; i < rows; i++) {
				for (int j = 0; j < columns; j++) {
					if (i == 0 || i == rows - 1) {
						char w = 254;
						cout << w << " ";
					}
					else {
						if (i == r && j == c) {
							cout << GREEN << "C" << DEFAULT << " "; // Print car symbol at the current position
						}
						else if (tempMap[i][j].value == 10) {
							cout << YELLOW << "|" << DEFAULT << " "; // Print user's path
						}
						else if (tempMap[i][j].value == 20) {
							cout << YELLOW << "<" << DEFAULT << " "; // Print user's path
						}
						else if (tempMap[i][j].value == 30) {
							cout << YELLOW << "|" << DEFAULT << " "; // Print user's path
						}
						else if (tempMap[i][j].value == 40) {
							cout << YELLOW << ">" << DEFAULT << " "; // Print user's path
						}

						else if (tempMap[i][j].value == -5) {
							cout << RED << "O" << DEFAULT << " "; // Print obstacle
						}
						else if (tempMap[i][j].value == -1) {
							char w = 254;
							cout << w << " "; // Print wall
						}
						else if (tempMap[i][j].value == 1) {
							cout << ". "; // Print path
						}
						else if (tempMap[i][j].value == 2) {
							char p = '*';
							cout << p << " "; // Print power-up
						}
						else if (tempMap[i][j].value == 100) {
							cout << "E" << " "; // Print destination
						}

						else {
							cout << ". ";
						}
					}
				}
				cout << endl;
			}
		}
		// Clean up the temporary map
		for (int i = 0; i < rows; i++) {
			delete[] tempMap[i];
		}
		delete[] tempMap;
	}

	void displayCollectedPowerUps() {
		cout << GREEN << "\033[1mCollected Power-Ups: " << endl;
		PowerUpNode* current = collectedPowerUps.head;
		if (!current) {
			cout << "0" << endl;
		}
		while (current != nullptr) {
			cout << "Power-Up at (" << current->data.x << ", " << current->data.y << ") of type " << current->data.type << endl;
			current = current->next;
		}
		cout << RESET;
	}
	//    // Dijkstra's algorithm to find the shortest path

	~Graph() {
		for (int i = 0; i < rows; i++) {
			delete[] Map[i];
		}
		delete[] Map;
		// Add code to delete edges in LinkedList
	}
};

void displayLeaderboard() {
	system("CLS");
	displayHeader();

	displaying_leaderboard(leaderboardRoot);

	std::cout << GREEN << "Press any key to go back to the menu...";
	_getch();
}



bool isValidPathExists(Graph& g, int startX, int startY, int endX, int endY) {
	vector<vector<pair<int, int>>> parent(g.getRows(), vector<pair<int, int>>(g.getColumns(), { -1, -1 }));
	vector<vector<int>> distance(g.getRows(), vector<int>(g.getColumns(), INT_MAX));
	CustomPriorityQueue<pair<int, pair<int, int>>, greater<pair<int, pair<int, int>>>> pq;

	// Initialize the source vertex
	distance[startX][startY] = 0;
	pq.push({ 0, {startX, startY} });

	// Define direction arrays for moving in 4 directions
	int dr[] = { -1, 1, 0, 0 };
	int dc[] = { 0, 0, -1, 1 };

	while (!pq.isEmpty()) {
		int dist = pq.top().first;
		int r = pq.top().second.first;
		int c = pq.top().second.second;
		pq.pop();

		if (dist > distance[r][c]) continue;

		for (int i = 0; i < 4; ++i) {
			int newR = r + dr[i];
			int newC = c + dc[i];

			if (g.isValidMove(newR, newC) && distance[newR][newC] > distance[r][c] + 1) {
				distance[newR][newC] = distance[r][c] + 1;
				parent[newR][newC] = { r, c };
				pq.push({ distance[newR][newC], {newR, newC} });
			}
		}
	}

	// Check if there exists a path to the destination
	return parent[endX][endY] != make_pair(-1, -1);
}

void createValidMap(Graph& g) {
	while (true) {
		g.createMap();
		if (isValidPathExists(g, 1, 1, g.getRows() - 2, g.getColumns() - 2)) {
			break;
		}
	}
}

void Instructions() {
	while (1) {
		system("CLS");
		gotoxy(40, 1); cout << YELLOW << " --------------------------------- ";
		gotoxy(40, 2); cout << YELLOW << " |          " << RED << "Instructions          " << YELLOW << " | ";
		gotoxy(40, 3); cout << YELLOW << " --------------------------------- ";

		// Draw the table top border
		gotoxy(25, 4); cout << YELLOW << "  +------------------+------------------+ ";

		// Draw the table header
		gotoxy(25, 5); cout << YELLOW << "  | " << DEFAULT << "Key              | Action                |" << YELLOW << " ";

		// Draw the header bottom border
		gotoxy(25, 6); cout << YELLOW << "  +------------------+----------------------------+ ";

		// Draw the table content with borders
		gotoxy(25, 7); cout << YELLOW << "  | " << GREEN << "W - Move Up		 | E - Destination      |" << YELLOW << " ";
		gotoxy(25, 8); cout << YELLOW << "  | " << GREEN << "A - Move Left       | D - Move Right       |" << YELLOW << " ";
		gotoxy(25, 9); cout << YELLOW << "  | " << GREEN << "S - Move Down       | ESC - Go Back        |" << YELLOW << " ";

		// Draw the instructions within the same table
		gotoxy(25, 10); cout << YELLOW << "  | " << GREEN << "3. Can't move the  | 4. Hitting a car     |" << YELLOW << " ";
		gotoxy(25, 11); cout << YELLOW << "  | " << GREEN << "Car in the direct  | by an obstacle can   |" << YELLOW << " ";
		gotoxy(25, 12); cout << YELLOW << "  | " << GREEN << "ion where there    | decrease your score  |" << YELLOW << " ";
		gotoxy(25, 13); cout << YELLOW << "  | " << GREEN << "exists a Wall.     | 5. Collect Power-    |" << YELLOW << " ";
		gotoxy(25, 14); cout << YELLOW << "  | " << GREEN << "                   | Ups to Increase      |" << YELLOW << " ";
		gotoxy(25, 15); cout << YELLOW << "  | " << GREEN << "                   | your score Rapidly.  |" << YELLOW << " ";

		// Draw the table bottom border
		gotoxy(25, 16); cout << YELLOW << "  +------------------+------------------+ ";

		cout << DEFAULT << endl;
		gotoxy(25, 18);cout << RED << "Press ESC to go back to the menu." << RESET << endl;
		char opt;
		opt = _getch();
		if (opt == 27)
			break;
	}
}



int SelectMode() {
	char key;

	system("CLS");
	gotoxy(40, 1); cout << YELLOW << " -------------------------- ";
	gotoxy(40, 2); cout << YELLOW << " |       " << RED << "Select Mode     " << YELLOW << " | ";
	gotoxy(40, 3); cout << YELLOW << " --------------------------";
	gotoxy(47, 6); cout << YELLOW << "1. Easy ";
	gotoxy(47, 8); cout << "2. Medium";
	gotoxy(47, 10); cout << "3. Hard";
	cout << DEFAULT;

	while (true) {
		key = _getch(); // Capture the key press without waiting for enter to be pressed

		switch (key) {
		case '1':

			cout << "You selected Easy Mode\n";
			return 20;
		case '2':

			cout << "You selected Medium Mode\n";
			return 30;
		case '3':

			cout << "You selected Hard Mode\n";
			return 40;
		default:
			cout << "Invalid choice. Please select 1, 2, or 3.\n";
		}
	}
}
void updateLeaderboard(const std::string& username, int score,int gameDuration) {
	leaderboardRoot = insert_the_players_details(leaderboardRoot, username, score, gameDuration);

	std::ofstream leaderboardFile("leaderboard.txt");
	if (leaderboardFile.is_open()) {
		writing_the_leader_board_in_file(leaderboardRoot, leaderboardFile);
		leaderboardFile.close();
	}
}




int main() {
	char choice;
	bool running = true;
	int rows = 20, columns = 20;

	readLeaderboard(); // Populate the BST from file

	while (running) {
		system("cls");
		gotoxy(40, 1); cout << YELLOW << " +------------------------+ ";
		gotoxy(40, 2); cout << YELLOW << " |" << RED << "       Maze Racer       " << YELLOW << "| ";
		gotoxy(40, 3); cout << YELLOW << " +------------------------+";
		gotoxy(47, 4); cout << RED << "   _______    ";
		gotoxy(47, 5); cout << "  /|||_\\`._ ";
		gotoxy(47, 6); cout << " (   _    _ _\\ ";
		gotoxy(47, 7); cout << "=`-(_)--(_)--' ";

		gotoxy(43, 9); cout << DEFAULT << "Menu Options";
		gotoxy(41, 10); cout << YELLOW << " +----------------------+ ";
		gotoxy(41, 11); cout << YELLOW << " | " << BLUE << "(1) Start Game       " << YELLOW << "| ";
		gotoxy(41, 12); cout << YELLOW << " +----------------------+ ";
		gotoxy(41, 13); cout << YELLOW << " | " << BLUE << "(2) Instructions     " << YELLOW << "| ";
		gotoxy(41, 14); cout << YELLOW << " +----------------------+ ";
		gotoxy(41, 15); cout << YELLOW << " | " << BLUE << "(3) Select Mode     " << YELLOW << " | ";
		gotoxy(41, 16); cout << YELLOW << " +----------------------+ ";
		gotoxy(41, 17); cout << YELLOW << " | " << BLUE << "(4) Leaderboard     " << YELLOW << " | ";
		gotoxy(41, 18); cout << YELLOW << " +----------------------+ ";
		gotoxy(41, 19); cout << YELLOW << " | " << BLUE << "(5) Exit             " << YELLOW << "| ";
		gotoxy(41, 20); cout << YELLOW << " +----------------------+ ";
		cout << DEFAULT;

		choice = _getch();

		switch (choice) {
		case '1': {
			system("CLS");

			// Ask for the username
			string username;
			cout << "Enter your username: ";
			cin.ignore(); // Ignore newline character from previous inputs
			getline(cin, username);

			Graph g(rows, columns);
			createValidMap(g);
			g.startGame();

			// Update the leaderboard with the user's score and username
			leaderboardRoot = insert_the_players_details(leaderboardRoot, username, g.getScore(), g.getDuration());

			// Write updated leaderboard to file
			std::ofstream file("leaderboard.txt");
			writing_the_leader_board_in_file(leaderboardRoot, file);
			file.close();

			break;
		}
		case '2':
			Instructions();
			break;
		case '3': {
			int x = SelectMode();
			rows = x;
			columns = x;
			break;
		}
		case '4':
			// Leaderboard display logic...
			system("CLS");
			displayLeaderboard();
			//displaying_leaderboard(leaderboardRoot);
			cout << "Press any key to go back to the menu...";
			_getch();
			break;
		case '5':
			running = false;
			break;
		default:
			// Invalid choice logic...
			break;
		}
	}

	return 0;
}