#include <iostream>
#include <fstream>
#define RED "\033[31m"
#define RESET "\033[37m"
#define CYAN "\033[36m"
using namespace std;

// Function to set the cursor position on the console
void gotoxy(int x, int y) {
    COORD pos = { static_cast<SHORT>(x), static_cast<SHORT>(y) };
    HANDLE output = GetStdHandle(STD_OUTPUT_HANDLE);
    SetConsoleCursorPosition(output, pos);
}

// Node class definition for a binary tree node
class Node {
public:
    string name;
    int score;
    int timeTaken;
    Node* left_child;
    Node* right_child;

    Node() {
        name = "";
        score = 0;
        timeTaken = 0;
        left_child = nullptr;
        right_child = nullptr;
    }

    Node(string name, int score, int time) {
        this->name = name;
        this->score = score;
        timeTaken = time;
        left_child = nullptr;
        right_child = nullptr;
    }
};

// Function to insert player details into a binary tree
Node* insert_the_players_details(Node* root, string name, int score, int gameDuration) {
    if (root == nullptr) {
        return new Node(name, score, gameDuration);
    }
    else {
        if (score < root->score) {
            root->left_child = insert_the_players_details(root->left_child, name, score, gameDuration);
        }
        else {
            root->right_child = insert_the_players_details(root->right_child, name, score, gameDuration);
        }
    }
    return root;
}

// Function to write leaderboard data to a file
void writing_the_leader_board_in_file(Node* root, ostream& leaderboard_in_file) {
    if (root == nullptr) return;
    writing_the_leader_board_in_file(root->left_child, leaderboard_in_file);
    leaderboard_in_file << root->name << " "
        << root->score << " "
        << root->timeTaken << endl;
    writing_the_leader_board_in_file(root->right_child, leaderboard_in_file);
}

// Function to display the leaderboard on the console
void displaying_leaderboard(Node* root) {
    if (root == nullptr) {
        return;
    }

    displaying_leaderboard(root->right_child);

    // Displaying leaderboard data with proper formatting
    cout << CYAN << "| " << left << setw(20) << root->name
        << " | " << setw(7) << root->score
        << " | " << setw(3) << root->timeTaken << " seconds "
        << "|" << endl;
    cout << "+----------------------+--------+-------------+" << RESET << endl;

    displaying_leaderboard(root->left_child);
}

// Function to display the leaderboard header
void displayHeader() {
    cout << RED << "+----------------------+--------+-------------+" << endl;
    cout << "| Player               | Score  |    Time     |" << endl;
    cout << "+----------------------+--------+-------------+" << RESET << endl;
}

// Function to search for a player in a file
void searching_in_file(string name, ifstream& leaderboard_file) {
    if (!leaderboard_file.is_open()) {
        cout << "Error in opening file." << endl;
        return;
    }

    string player_name;
    int player_score;
    bool player_found = false;

    while (leaderboard_file >> player_name >> player_score) {
        if (player_name == name) {
            cout << "Player found: " << player_name << ", Latest Score: " << player_score << endl;
            player_found = true;
            break;
        }
    }

    if (!player_found) {
        cout << "Player not found: " << name << endl;
    }
}
