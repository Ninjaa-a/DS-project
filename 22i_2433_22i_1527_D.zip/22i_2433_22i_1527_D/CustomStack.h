#pragma once

// Define a custom stack template class
template<typename T>
class CustomStack {
    // Define a private struct for stack nodes
    struct Node {
        T data;
        Node* next;
        Node(T val) : data(val), next(nullptr) {}
    };

    Node* topNode; // Pointer to the top of the stack

public:
    // Constructor: Initialize an empty stack
    CustomStack() : topNode(nullptr) {}

    // Destructor: Deallocate memory for all stack nodes
    ~CustomStack() {
        while (!isEmpty()) {
            pop();
        }
    }

    // Push an element onto the stack
    void push(T val) {
        Node* newNode = new Node(val);
        newNode->next = topNode; // Link the new node to the previous top
        topNode = newNode;       // Update the top to the new node
    }

    // Pop and remove the top element from the stack
    void pop() {
        if (isEmpty()) {
            throw std::out_of_range("Stack underflow");
        }
        Node* temp = topNode;
        topNode = topNode->next; // Move the top to the next node
        delete temp;             // Deallocate memory for the previous top node
    }

    // Get the value of the top element without removing it
    T top() {
        if (isEmpty()) {
            throw std::out_of_range("Stack underflow");
        }
        return topNode->data;
    }

    // Check if the stack is empty
    bool isEmpty() {
        return topNode == nullptr;
    }
};
