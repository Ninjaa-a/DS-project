#pragma once

// Define a custom queue template class
template<typename T>
class CustomQueue {
private:
    // Define a private struct for queue nodes
    struct Node {
        T data;
        Node* next;

        Node(T data) : data(data), next(nullptr) {}
    };

    Node* front; // Pointer to the front (head) of the queue
    Node* rear;  // Pointer to the rear (tail) of the queue
    int size;    // Number of elements in the queue

public:
    // Constructor: Initialize an empty queue
    CustomQueue() : front(nullptr), rear(nullptr), size(0) {}

    // Destructor: Deallocate memory for all queue nodes
    ~CustomQueue() {
        while (front != nullptr) {
            Node* temp = front;
            front = front->next;
            delete temp;
        }
    }

    // Function to enqueue an element at the rear of the queue
    void enqueue(T data) {
        Node* newNode = new Node(data);
        if (rear == nullptr) {
            // If the queue is empty, set both front and rear to the new node
            front = rear = newNode;
        }
        else {
            // Otherwise, add the new node to the rear and update the rear pointer
            rear->next = newNode;
            rear = newNode;
        }
        size++;
    }

    // Function to dequeue and remove the front element from the queue
    void dequeue() {
        if (front == nullptr) {
            // If the queue is empty, do nothing
            return;
        }
        Node* temp = front;
        front = front->next;
        if (front == nullptr) {
            // If the front becomes nullptr (queue becomes empty), update rear as well
            rear = nullptr;
        }
        delete temp;
        size--;
    }

    // Function to peek at the front element of the queue without removing it
    T peek() const {
        if (front == nullptr) {
            throw std::runtime_error("Queue is empty");
        }
        return front->data;
    }

    // Function to check if the queue is empty
    bool isEmpty() const {
        return size == 0;
    }

    // Function to get the current size (number of elements) of the queue
    int getSize() const {
        return size;
    }
};
