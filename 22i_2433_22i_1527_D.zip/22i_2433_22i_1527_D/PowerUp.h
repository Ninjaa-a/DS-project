#pragma once
// Define a structure to represent a PowerUp
struct PowerUp {
    int x, y;  // Coordinates of the power-up
    char type; // Type of the power-up

    PowerUp(int x, int y, char type) : x(x), y(y), type(type) {}
};

// Define a class to represent a node in a PowerUp linked list
class PowerUpNode {
public:
    PowerUp data;       // Data (a PowerUp) stored in the node
    PowerUpNode* next; // Pointer to the next node

    PowerUpNode(PowerUp data) : data(data), next(nullptr) {}
};

// Define a class to represent a linked list of PowerUps
class PowerUpList {
public:
    PowerUpNode* head; // Pointer to the head (start) of the list

    PowerUpList() : head(nullptr) {}

    // Function to add a PowerUp to the beginning of the list
    void addPowerUp(PowerUp data) {
        PowerUpNode* newNode = new PowerUpNode(data);
        newNode->next = head;
        head = newNode;
    }

    // Destructor: Deallocate memory for all PowerUp nodes in the list
    ~PowerUpList() {
        PowerUpNode* current = head;
        while (current != nullptr) {
            PowerUpNode* next = current->next;
            delete current;
            current = next;
        }
        head = nullptr;
    }
};
