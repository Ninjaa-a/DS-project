#pragma once

// Include necessary headers
#include <vector>
#include <stdexcept>

// Define a custom priority queue template class
template <typename T, typename Comparator = std::less<T>>
class CustomPriorityQueue {
private:
    std::vector<T> data;  // Storage for elements in the priority queue
    Comparator comp;      // Comparator function to determine element priority

    // Helper function to maintain the heap property (min-heap in this case)
    void heapify(int index) {
        int smallest = index;
        int left = 2 * index + 1;
        int right = 2 * index + 2;

        // Compare with left child
        if (left < data.size() && comp(data[left], data[smallest]))
            smallest = left;

        // Compare with right child
        if (right < data.size() && comp(data[right], data[smallest]))
            smallest = right;

        // If the smallest is not the current index, swap and recursively heapify
        if (smallest != index) {
            std::swap(data[index], data[smallest]);
            heapify(smallest);
        }
    }

public:
    // Constructor
    CustomPriorityQueue() {}

    // Push an element into the priority queue
    void push(T value) {
        data.push_back(value);
        int index = data.size() - 1;
        int parent = (index - 1) / 2;

        // Reorder elements to maintain the heap property
        while (index > 0 && comp(data[index], data[parent])) {
            std::swap(data[index], data[parent]);
            index = parent;
            parent = (index - 1) / 2;
        }
    }

    // Pop the top element from the priority queue
    void pop() {
        if (data.size() > 0) {
            data[0] = data.back();
            data.pop_back();
            heapify(0);
        }
    }

    // Get the top element from the priority queue
    T top() {
        if (data.size() > 0)
            return data[0];
        throw std::runtime_error("Priority queue is empty");
    }

    // Check if the priority queue is empty
    bool isEmpty() const {
        return data.empty();
    }
};
